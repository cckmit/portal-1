#!/bin/bash

export PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/mysql/bin
export LC_ALL=C

echo "** update  db **"
mysql -u $1 -p$2 < db-patch.sql
echo "** update db end  **"
