#!/bin/bash

BACKUP_PATH="/usr/protei/backup"
USER_NAME="support"

DB_BACKUP="${BACKUP_PATH}/db/beforedeploy"
DB_NAME="portal"
BACKUP_FILE="${DB_NAME}_`date "+%Y_%m_%d"`"

export PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/mysql/bin
export LC_ALL=C

echo "** backup db ** "
mkdir -p "${DB_BACKUP}"
mysqldump -u $1 -p$2 $DB_NAME | gzip --fast > "${DB_BACKUP}/${BACKUP_FILE}.gz" || exit 1
echo "** backup db end  - "${DB_BACKUP}/${BACKUP_FILE}.gz" ** "

CFG_PATH="/opt/tomcat/latest/cfg"
CFG_BACKUP="${BACKUP_PATH}/config"
CFG_NAME="cfg_`date "+%Y_%m_%d"`"
echo "** backup cfg ** "
mkdir -p "${CFG_BACKUP}"
cd "${CFG_PATH}" || exit 1
find . -type f | tar cf - --files-from=- | gzip --fast > "${CFG_BACKUP}/${CFG_NAME}.tgz" || exit 1
cd - > /dev/null
echo "** backup cfg end - ${CFG_BACKUP}/${CFG_NAME}.tgz ** "

WEB_PATH="/opt/tomcat/latest/webapps/portal"
WEB_BACKUP="${BACKUP_PATH}/web"
WEB_NAME="portal_`date "+%Y_%m_%d"`"
echo "** backup web ** "
mkdir -p "${WEB_BACKUP}"
cd "${WEB_PATH}" || exit 1
find . -type f | tar cf - --files-from=- | gzip --fast > "${WEB_BACKUP}/${WEB_NAME}.tgz" || exit 1
cd - > /dev/null
echo "** backup web end - ${WEB_BACKUP}/${WEB_NAME}.tgz ** "