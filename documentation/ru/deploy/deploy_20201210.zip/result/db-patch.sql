use portal;

update user_role
set privileges = CONCAT(privileges,',ABSENCE_VIEW,ABSENCE_CREATE,ABSENCE_EDIT,ABSENCE_REMOVE,ABSENCE_REPORT')
where id = 6;
