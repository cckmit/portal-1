#!/bin/bash

export PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/mysql/bin
export LC_ALL=C

echo "** download cfg ** "
mkdir -p crm
ssh -tt -L 1234:10.0.0.18:22 support@192.168.110.68 &
sleep 1.0
scp -P 1234 frost@localhost:/tomcat/cfg/portal.properties ./crm/portal.properties
pkill -f 'ssh -tt -L 1234:10.0.0.18:22'
cp ./crm/portal.properties ./crm/portal_edit.properties
echo "** download cfg end ** "



# ssh -L 1234:192.168.110.68:22 support@192.168.110.68 cat -
# ssh -L 1234:10.0.0.18:22 -p 45678 support@192.168.110.68
# scp support@192.168.110.68:/opt/tomcat/latest/cfg/portal.properties ./cfg/portal.properties
# scp -P 1234 support@127.0.0.1:/tomcat/cfg/portal.properties ./crm/portal.properties
# scp -P 1234 frost@localhost:/tomcat/cfg/portal.properties ./crm/portal.properties

